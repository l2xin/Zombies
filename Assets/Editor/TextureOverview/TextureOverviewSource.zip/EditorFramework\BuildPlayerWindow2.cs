﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public class BuildPlatform2
    {
        public BuildTarget DefaultTarget;
        public BuildTargetGroup TargetGroup;
        public string Name;
        public string DisplayName;
        public Texture Image;
        public Texture SmallIcon;
    }

    /// <summary>
    /// BuildPlayerWindow2 provides helper methods to get information about build pipeline specifics.
    /// </summary>
    /// <remarks>
    /// Most BuildPlayerWindow2 methods are actually available in UnityEditor.BuildPlayerWindow, but
    /// they are not public in there. BuildPlayerWindow2 is basically a wrapper to get access to those hidden methods.
    /// </remarks>
    public class BuildPlayerWindow2
    {
        #region Private Fields
        static Type _type;
        static MethodInfo _getValidPlatforms;
        static List<BuildPlatform2> _validplatforms; // cached result of a GetValidPlatforms() call
        static Texture2D[] _platformImages;
        static List<BuildTargetGroup> _validplatformgroups;
        #endregion

        #region ctor
        static BuildPlayerWindow2()
        {
            _type = typeof(EditorWindow).Assembly.GetType("UnityEditor.BuildPlayerWindow");
            if (_type != null)
            {
                _getValidPlatforms = _type.GetMethod("GetValidPlatforms", BindingFlags.Static | BindingFlags.NonPublic);
            }

            if (null == _type)
                Debug.LogWarning("Could not find type 'UnityEditor.BuildPlayerWindow'.");


            if (null == _getValidPlatforms)
                Debug.LogWarning("Could not find method 'UnityEditor.BuildPlayerWindow.GetValidPlatforms'.");
        }
        #endregion

        public static BuildPlatform2 FindPlatform(string name)
        {
            var platforms = GetValidPlatforms();
            for (var n = 0; n < platforms.Count; ++n)
            {
                if (string.Equals(name, platforms[n].Name, StringComparison.OrdinalIgnoreCase))
                    return platforms[n];
            }
            return null;
        }

        #region GetPlatformImage
        /// <summary>
        /// Gets the image for the specified platform.
        /// </summary>
        /// <param name="platform">The platform.</param>
        /// <returns>The image on success, null otherwise.</returns>
        public static Texture2D GetPlatformImage(BuildTargetGroup platform)
        {
            if (_platformImages == null)
            {
                var platforms = GetValidPlatforms();
                _platformImages = new Texture2D[32];
                foreach (var v in _validplatforms)
                    _platformImages[(int)v.TargetGroup] = v.Image as Texture2D;
            }

            var index = (int)platform;
            if (index < 0 && index >= _platformImages.Length)
                return null;

            return _platformImages[index];
        }
        #endregion

        #region GetValidPlatforms
        /// <summary>
        /// Gets a list of BuildTargetGroup elements that describe valid/supported platforms.
        /// </summary>
        /// <returns>The list on success, an empty list otherwise.</returns>
        public static List<BuildTargetGroup> GetValidPlatformGroups()
        {
            if (_validplatformgroups != null)
                return _validplatformgroups;

            _validplatformgroups = new List<BuildTargetGroup>();
            foreach (var p in GetValidPlatforms())
                _validplatformgroups.Add(p.TargetGroup);

            return _validplatformgroups;
        }

        /// <summary>
        /// Gets a list of BuildPlatform2 elements that describe valid/supported platforms.
        /// </summary>
        /// <returns>The list on success, an empty list otherwise.</returns>
        public static List<BuildPlatform2> GetValidPlatforms()
        {
            if (null != _validplatforms)
                return new List<BuildPlatform2>(_validplatforms);

            var result = new List<BuildPlatform2>();
            if (null == _getValidPlatforms)
                return result;


            var enumerable = _getValidPlatforms.Invoke(null, null) as IEnumerable;
            if (null == enumerable)
                return result;

            foreach (var item in enumerable)
            {
                var entry = new BuildPlatform2();
                result.Add(entry);

                var type = item.GetType();
                var namefield = type.GetField("name");
                if (null != namefield)
                    entry.Name = namefield.GetValue(item) as string;

                var targetgroupfield = type.GetField("targetGroup");
                if (null != targetgroupfield)
                    entry.TargetGroup = (BuildTargetGroup)targetgroupfield.GetValue(item);

                var defaulttargerproperty = type.GetProperty("DefaultTarget");
                if (null != defaulttargerproperty)
                    entry.DefaultTarget = (BuildTarget)defaulttargerproperty.GetValue(item, null);

                var contentfield = type.GetField("title");
                if (null != contentfield)
                {
                    var content = contentfield.GetValue(item) as GUIContent;
                    if (null != content)
                    {
                        entry.DisplayName = content.text;
                        entry.Image = content.image;
                        entry.SmallIcon = content.image;
                    }
                }

                var smallIconfield = type.GetField("smallIcon");
                if (smallIconfield != null)
                    entry.SmallIcon = smallIconfield.GetValue(item) as Texture2D;

                //Debug.Log("Name: " + entry.Name + ", TargetGroup: " + entry.TargetGroup + ", DefaultTarget:" + entry.DefaultTarget);
            }

            _validplatforms = new List<BuildPlatform2>(result);
            return result;
        }
        #endregion
    }
}
