﻿//---------------------------------------
// Copyright (c) 2012-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// EditorGUIUtility2 provides helper methods to access non-public methods in EditorGUIUtility.
    /// </summary>
    /// <remarks>
    public static class EditorGUIUtility2
    {
        #region Private Fields
        static MethodInfo _loadIcon;
        static PropertyInfo _labelWidth;
        static System.Collections.Generic.List<float> _labelWidthStack = new System.Collections.Generic.List<float>();
        #endregion

        #region ctor
        static EditorGUIUtility2()
        {
            _loadIcon = typeof(EditorGUIUtility).GetMethod("LoadIcon", BindingFlags.Static | BindingFlags.NonPublic);
            
            _labelWidth = typeof(EditorGUIUtility).GetProperty("labelWidth", BindingFlags.Static | BindingFlags.NonPublic); // internal in 4.1.2
            if (_labelWidth == null)
                _labelWidth = typeof(EditorGUIUtility).GetProperty("labelWidth", BindingFlags.Static | BindingFlags.Public);// public in 4.3

            if (null == _loadIcon)
                Debug.LogWarning("Could not find method 'UnityEditor.EditorGUIUtility.LoadIcon'.");

            if (null == _labelWidth)
                Debug.LogWarning("Could not find property 'UnityEditor.EditorGUIUtility.labelWidth'.");
        }
        #endregion

        #region labelWidth
        /// <summary>
        /// The width in pixels reserved for labels of Editor GUI controls.
        /// </summary>
        /// <remarks>
        /// EditorGUIUtility.labelWidth is an internal property in Unity 4.1, but
        /// has been exposed publicly in Unity 4.3. In order to support all Unity versions,
        /// we use reflection to get our hands on this property.
        /// </remarks>
        public static float labelWidth
        {
            get
            {
                if (_labelWidth != null)
                    return (float)_labelWidth.GetValue(null, null);
                return 150;
            }
            set
            {
                if (_labelWidth != null)
                    _labelWidth.SetValue(null, value, null);
            }
        }

        /// <summary>
        /// Begins a group that uses the specified width.
        /// </summary>
        /// <param name="width">The new label width</param>
        public static void BeginLabelWidth(float width)
        {
            _labelWidthStack.Add(labelWidth);
            labelWidth = width;

            // try to handle warnings for non-matching Push/Pop's
            if (_labelWidthStack.Count == 50)
            {
                Debug.LogWarning("EditorGUIUtility2: PushLabelWidth/PopLabelWidth pairs don't match.");
                _labelWidthStack.Clear();
            }
        }

        /// <summary>
        /// Ends a label width group started with BeginLabelWidth.
        /// </summary>
        public static void EndLabelWidth()
        {
            if (_labelWidthStack.Count > 0)
            {
                var index = _labelWidthStack.Count - 1;
                labelWidth = _labelWidthStack[index];
                _labelWidthStack.RemoveAt(index);
            }
            else
                Debug.LogWarning("EditorGUIUtility2: PushLabelWidth/PopLabelWidth pairs don't match.");
        }
        #endregion

        #region LoadIcon
        /// <summary>
        /// Gets an icon of the editor built-in resources.
        /// </summary>
        /// <param name="path">The built-in resource path.</param>
        /// <returns>The icon on success, null otherwise.</returns>
        public static Texture2D LoadIcon(string path)
        {
            if (null == _loadIcon)
                return null;

            var args = new object[] { path };
            return _loadIcon.Invoke(null, args) as Texture2D;
        }
        #endregion
    }
}
