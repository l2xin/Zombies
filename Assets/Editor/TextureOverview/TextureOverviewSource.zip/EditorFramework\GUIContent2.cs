﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using UnityEngine;

namespace EditorFramework
{
    /// <summary>
    /// Helper class to temporarily get a GUIContent object.
    /// </summary>
    /// <remarks>
    /// This class is actually only useful to avoid garbage.
    /// It returns a reference to the same GUIContent object always,
    /// so be careful not to overwrite its content when using in nested fashion.
    /// </remarks>
    public static class GUIContent2
    {
        static GUIContent _content = new GUIContent();

        public static GUIContent Temp(string text)
        {
            _content.text = text;
            _content.image = null;
            _content.tooltip = null;
            return _content;
        }

        public static GUIContent Temp(string text, Texture image)
        {
            _content.text = text;
            _content.image = image;
            _content.tooltip = null;
            return _content;
        }

        public static GUIContent Temp(string text, Texture image, string tooltip)
        {
            _content.text = text;
            _content.image = image;
            _content.tooltip = tooltip;
            return _content;
        }

        public static GUIContent Temp(string text, string tooltip)
        {
            _content.text = text;
            _content.image = null;
            _content.tooltip = tooltip;
            return _content;
        }

        public static GUIContent Temp(Texture image)
        {
            _content.text = null;
            _content.image = image;
            _content.tooltip = null;
            return _content;
        }

        public static GUIContent Temp(Texture image, string tooltip)
        {
            _content.text = null;
            _content.image = image;
            _content.tooltip = tooltip;
            return _content;
        }
    }
}
