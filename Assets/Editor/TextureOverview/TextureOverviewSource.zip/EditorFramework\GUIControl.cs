﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// Describes the status of a GUIControl.
    /// </summary>
    [Flags]
    public enum GUIControlStatus
    {
        None = 0,

        /// <summary>
        /// The control is enabled.
        /// </summary>
        Enable = 1<<0,

        /// <summary>
        /// The control is visible.
        /// </summary>
        Visible = 1<<1,

        /// <summary>
        /// The control is checked. Think of a checkbox.
        /// </summary>
        Checked = 1<<2
    }

    public delegate void GUIControlExecuteDelegate(GUIControl sender);
    public delegate GUIControlStatus GUIControlQueryStatusDelegate(GUIControl sender);

    /// <summary>
    /// The GUIControl class is the base class for all controls used in EditorFramework.
    /// </summary>
    /// <remarks>
    /// Derived classes override DoGUI() to implement their custom control handling.
    /// </remarks>
    public abstract class GUIControl
    {
        GUIControlStatus _cachedControlStatus;

        /// <summary>
        /// Gets or sets the text displayed on the control.
        /// </summary>
        public string Text = "";

        /// <summary>
        /// Gets or sets the text that appears as a ToolTip for the control.
        /// </summary>
        public string Tooltip = "";

        /// <summary>
        /// Gets or sets the image for this control.
        /// </summary>
        public Texture2D Image;

        /// <summary>
        /// Gets or sets the image size (in pixels) for this control.
        /// </summary>
        public Vector2 ImageSize = new Vector2(16, 16);

        /// <summary>
        /// Gets or sets the GUIStyle for the control.
        /// </summary>
        public GUIStyle Style = GUI.skin.button;

        /// <summary>
        /// Specifies how the control is layouted.
        /// </summary>
        public GUILayoutOption[] LayoutOptions = new GUILayoutOption[0];

        /// <summary>
        /// Custom tag for user data.
        /// </summary>
        public System.Object Tag;

        /// <summary>
        /// Gets the parent container of the control.
        /// </summary>
        public GUIControl Parent
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the EditorWindow where this control resides in.
        /// </summary>
        public EditorWindow Editor
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the name of the control.
        /// </summary>
        /// <remarks>The name is actually a GUID to avoid name clashes.</remarks>
        public string ControlName
        {
            get;
            private set;
        }

        /// <summary>
        /// Occurs when the control get executed.
        /// For example, when a button gets clicked.
        /// </summary>
        public GUIControlExecuteDelegate Execute;

        /// <summary>
        /// Occurs when the control has to report its status.
        /// </summary>
        public GUIControlQueryStatusDelegate QueryStatus;

        /// <summary>
        /// Initializes a new instance of the GUIControl class.
        /// </summary>
        /// <param name="editor">The EditorWindow where this control resides in.</param>
        /// <param name="parent">The parent container of the control or null when it's a top-level control.</param>
        public GUIControl(EditorWindow editor, GUIControl parent)
        {
            this.ControlName = Guid.NewGuid().ToString();
            this.Editor = editor;
            this.Parent = parent;
        }

        /// <summary>
        /// Gets the status of the control.
        /// </summary>
        public GUIControlStatus OnQueryStatus()
        {
            var status = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (null != QueryStatus)
                status = QueryStatus.Invoke(this);

            // if this control has a parent, query the status of the parent too.
            // in case the parent control is disabled, its children must be disabled too.
            if (null != Parent)
            {
                var parentstatus = Parent.OnQueryStatus();

                if ((parentstatus & GUIControlStatus.Enable) == 0)
                    status &= ~GUIControlStatus.Enable;

                if ((parentstatus & GUIControlStatus.Visible) == 0)
                    status &= ~GUIControlStatus.Visible;
            }

            return status;
        }

        /// <summary>
        /// The application has to call this method during OnGUI() to update and
        /// draw the control.
        /// </summary>
        public void OnGUI()
        {
            // Change the state of a GUI element in the layout phase only,
            // because otherwise Unity's GUI system sometimes prints errors.
            if (Event.current.type == EventType.layout)
                _cachedControlStatus = OnQueryStatus();

            if ((_cachedControlStatus & GUIControlStatus.Visible) == 0)
                return;

            EditorGUI.BeginDisabledGroup((_cachedControlStatus & GUIControlStatus.Enable) == 0);
            GUI.SetNextControlName(ControlName);
            DoGUI();
            EditorGUI.EndDisabledGroup();
        }

        /// <summary>
        /// Sets input focus to the control.
        /// </summary>
        public void Focus()
        {
            GUI.FocusControl(ControlName);
        }

        /// <summary>
        /// Derived classes override this method and implement their custom control handling here.
        /// </summary>
        protected abstract void DoGUI();
    }
}
