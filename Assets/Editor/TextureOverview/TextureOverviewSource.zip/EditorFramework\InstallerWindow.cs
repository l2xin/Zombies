﻿//---------------------------------------
// Copyright (c) 2011-2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public class InstallerWindow : EditorWindow
    {
        #region Private Fields
        int _LayoutCalls;
        string _Title = "";
        string _Message = "";
        string _ErrorMessage = "";
        float _ErrorTime;
        GUIStyle _MessageStyle;
        #endregion

        /// <summary>
        /// Title of the plugin.
        /// </summary>
        public string ProductTitle = "";

        /// <summary>
        /// URL where to give feedback or get help about the plugin.
        /// </summary>
        public string FeedbackUrl = "";

        /// <summary>
        /// URL of the plugin in the asset store.
        /// </summary>
        public string AssetStoreUrl = "";

        /// <summary>
        /// The minimum required major version of the editor to run the plugin.
        /// </summary>
        public int MinimumMajorVersion = 4;


        /// <summary>
        /// The minimum required minor version of the editor to run the plugin.
        /// </summary>
        public int MinimumMinorVersion = 3;

        void OnGUI()
        {
            if (!InstallerWindow.ValidateVersion(MinimumMajorVersion, MinimumMinorVersion, ProductTitle, ProductTitle, FeedbackUrl))
            {
                Close();
                return;
            }

            // in case of an error, display the error message
            // however, wait 5 seconds before doing so, because sometimes a IOException: Win32 IO returned 1224 occurs
            // but it's harmless. And within these 5 seconds, the windows should be reloaded.
            if (!string.IsNullOrEmpty(_ErrorMessage) && _ErrorTime+5<Time.realtimeSinceStartup)
            {
                DrawInstallFailed();
                return;
            }

            // wait for the first layout call to initialize
            if (_LayoutCalls == 0 && Event.current.type == EventType.layout)
                Init();

            // wait for another layout call to actually replace the executing assembly.
            // we don't immediately replace the assembly, because we want to give unity
            // a change to render our window first, which is blocked during installation.
            if (_LayoutCalls == 2 && Event.current.type == EventType.layout)
            {
                Install();
                AssetDatabase.Refresh();
            }

            if (Event.current.type == EventType.layout)
                _LayoutCalls++;

            // draw the installation message
            GUILayout.Label(_Message, _MessageStyle, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));

            base.Repaint();
        }

        void DrawInstallFailed()
        {
            GUILayout.Label(new GUIContent(_Title + " - Setup failed", EditorFramework.Images.Error16x16), EditorStyles.boldLabel);
            if (GUILayout.Button(new GUIContent(" > Get help in Unity forum", FeedbackUrl), EditorFramework.GUIStyles.Hyperlink))
                Application.OpenURL(FeedbackUrl);
            EditorGUIUtility.AddCursorRect(GUILayoutUtility.GetLastRect(), MouseCursor.Link);

            GUILayout.Space(20);
            GUILayout.Label(_ErrorMessage, EditorStyles.wordWrappedLabel);
            GUILayout.Space(20);
        }

        void Init()
        {
            _Title = string.Format("{0} for Unity {1}", ProductTitle, EditorApplication2.MajorVersion);
            _Message = string.Format("Please wait while {0} is installed.", _Title);
            _MessageStyle = new GUIStyle(EditorStyles.boldLabel);
            _MessageStyle.wordWrap = true;
            _MessageStyle.alignment = TextAnchor.MiddleCenter;

            if (EditorApplication2.MajorVersion < 4)
                _ErrorMessage = string.Format("{0} requires Unity 4.x or Unity 5, but you are using Unity {1}.\n", ProductTitle, Application.unityVersion);
        }

        /// <summary>
        /// Replaces the currently executing assembly with another one.
        /// The file names must the following rules:
        /// * Installed assembly is called ProductName.dll (where ProductName is a placeholder for eg TextureOverview)
        /// * Available assemblies are called ProductName.dll.UnityMajorVersion, eg TextureOverview.dll.Unity4
        /// </summary>
        void Install()
        {
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews(); // register a repaint command, which seems to get executed after import and thus makes sure our window gets redrawn to show the new content
            var majorVersion = EditorApplication2.MajorVersion;
            var minorVersion = EditorApplication2.MinorVersion;
            if (majorVersion < MinimumMajorVersion || (majorVersion == MinimumMajorVersion && minorVersion < MinimumMinorVersion))
            {
                _ErrorTime = Time.realtimeSinceStartup;
                _ErrorMessage += string.Format("\nCannot install {0}. Unity {1}.{2} or higher is required to run {0}.\n", ProductTitle, MinimumMajorVersion, MinimumMinorVersion);
                return;
            }

            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            CopyFile(string.Format("{0}.Unity{1}", asm.Location, majorVersion), asm.Location, ref _ErrorMessage);
            CopyFile(string.Format("{0}.mdb.Unity{1}", asm.Location, majorVersion), asm.Location + ".mdb", ref _ErrorMessage);
        }

        void CopyFile(string sourcePath, string targetPath, ref string errorMsg)
        {
            try
            {
                System.IO.File.Copy(sourcePath, targetPath, true);
            }
            catch (System.Exception)
            {
                //Debug.LogException(e);
                _ErrorTime = Time.realtimeSinceStartup;
                errorMsg += string.Format("\nError while copying '{0}' to '{1}'. Please check if the file is read-only.\n", sourcePath, targetPath);
            }
        }

        public static bool ValidateVersion(int major, int minor, string productTitle, string productName, string feedbackUrl)
        {
            var title = string.Format("{0} Version Mismatch", productTitle);

#if UNITY_4 || UNITY_5

            var compiledForVersion=4;
#if UNITY_5
            compiledForVersion=5;
#endif

            // Display an error if the DLL is compiled for Unity 5, but it's currently running in Unity 4 or vica versa.
            if (EditorApplication2.MajorVersion != compiledForVersion)
            {
                var text = string.Format("{0} has detected that it is running in Unity {2}, but the installed version supports Unity {1} only.\n\n" +
                                         "Please download and install the latest {0} version from the Unity Asset Store.",
                                         productName,
                                         compiledForVersion,
                                         EditorApplication2.MajorVersion);

                if (!EditorUtility.DisplayDialog(title, text, "Close", "Help"))
                    Application.OpenURL(feedbackUrl);

                return false;
            }
#endif

            if (!EditorApplication2.IsVersionOrHigher(major, minor))
            {
                if (!EditorUtility.DisplayDialog(title,
                    string.Format("{0} requires Unity {1}.{2} or newer.\n\nPlease download and install the latest {0} version from the Unity Asset Store.", productName, major, minor), "Close", "Help"))
                    Application.OpenURL(feedbackUrl);

                return false;
            }

            return true;
        }
    }
}
