﻿//---------------------------------------
// Copyright (c) 2011-2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// TextureUtil2 provides various methods to get texture properties.
    /// </summary>
    /// <remarks>
    /// Some methods are actually available in UnityEditor.TextureUtil, but they are not public in there.
    /// </remarks>
    public static class TextureUtil2
    {
        #region Private Fields
        static Type _type;
        static MethodInfo _getTextureFormatString;
        static MethodInfo _getTextureFormat;
        static MethodInfo _countMipmaps;
        static MethodInfo _getStorageMemorySize;
        static MethodInfo _getUsageMode;
        static MethodInfo _hasAlphaTextureFormat;
        static MethodInfo _isCompressedTextureFormat;
        static MethodInfo _isNonPowerOfTwo;
        static MethodInfo _isCubemapReadable;
        static MethodInfo _getGLWidth;
        static MethodInfo _getGLHeight;
        #endregion

        #region ctor
        static TextureUtil2()
        {
            _type = typeof(TextureImporter).Assembly.GetType("UnityEditor.TextureUtil");
            if (_type != null)
            {
                _getTextureFormatString = _type.GetMethod("GetTextureFormatString", BindingFlags.Static | BindingFlags.Public);
                _getTextureFormat = _type.GetMethod("GetTextureFormat", BindingFlags.Static | BindingFlags.Public);
                
                _countMipmaps = _type.GetMethod("CountMipmaps", BindingFlags.Static | BindingFlags.Public);
                if (_countMipmaps == null)
                    _countMipmaps = _type.GetMethod("GetMipmapCount", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null); // Unity 5.4 renamed CountMipmaps to GetMipmapCount

                _getStorageMemorySize = _type.GetMethod("GetStorageMemorySize", BindingFlags.Static | BindingFlags.Public);
                _getUsageMode = _type.GetMethod("GetUsageMode", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null);
                _hasAlphaTextureFormat = _type.GetMethod("HasAlphaTextureFormat", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(TextureFormat) }, null);
                _isCompressedTextureFormat = _type.GetMethod("IsCompressedTextureFormat", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(TextureFormat) }, null);
                _isNonPowerOfTwo = _type.GetMethod("IsNonPowerOfTwo", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture2D) }, null);
                _isCubemapReadable = _type.GetMethod("IsCubemapReadable", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Cubemap) }, null);

                _getGLWidth = _type.GetMethod("GetGLWidth", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null);
                if (_getGLWidth == null)
                    _getGLWidth = _type.GetMethod("GetGPUWidth", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null); // Unity 5.4 renamed GetGLWidth to GetGPUWidth

                _getGLHeight = _type.GetMethod("GetGLHeight", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null);
                if (_getGLHeight == null)
                    _getGLHeight = _type.GetMethod("GetGPUHeight", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(Texture) }, null); // Unity 5.4 renamed GetGLHeight to GetGPUHeight

            }

            if (null == _type)
                Debug.LogWarning("Could not find type 'TextureUtil'.");

            if (null == _getTextureFormatString)
                Debug.LogWarning("Could not find method 'TextureUtil.GetTextureFormatString'.");

            if (null == _getTextureFormat)
                Debug.LogWarning("Could not find method 'TextureUtil.GetTextureFormat'.");

            if (null == _countMipmaps)
                Debug.LogWarning("Could not find method 'TextureUtil.CountMipmaps' or 'TextureUtil.GetMipmapCount(Texture)'.");

            if (null == _getStorageMemorySize)
                Debug.LogWarning("Could not find method 'TextureUtil.GetStorageMemorySize'.");

            if (null == _getUsageMode)
                Debug.LogWarning("Could not find method 'TextureUtil.GetUsageMode(Texture)'.");

            if (null == _hasAlphaTextureFormat)
                Debug.LogWarning("Could not find method 'TextureUtil.HasAlphaTextureFormat(TextureFormat)'.");

            if (null == _isCompressedTextureFormat)
                Debug.LogWarning("Could not find method 'TextureUtil.IsCompressedTextureFormat(TextureFormat)'.");

            if (null == _isNonPowerOfTwo)
                Debug.LogWarning("Could not find method 'TextureUtil.IsNonPowerOfTwo(Texture2D)'.");

            if (null == _isCubemapReadable)
                Debug.LogWarning("Could not find method 'TextureUtil.IsCubemapReadable(Cubemap)'.");

            if (null == _getGLWidth)
                Debug.LogWarning("Could not find method 'TextureUtil.GetGLWidth(Texture)' or 'TextureUtil.GetGPUWidth(Texture)'.");

            if (null == _getGLHeight)
                Debug.LogWarning("Could not find method 'TextureUtil.GetGLHeight(Texture)' or 'TextureUtil.GetGPUHeight(Texture)'.");
        }
        #endregion

        #region GetStorageMemorySize
        /// <summary>
        /// Gets the storage memory usage of the specified texture.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>The storage memory usage in bytes.</returns>
        public static int GetStorageMemorySize(Texture texture)
        {
            if (null == _getStorageMemorySize)
                return 0;

            var args = new object[] { texture };
            return (int)_getStorageMemorySize.Invoke(null, args);
        }
        #endregion

        #region GetRuntimeMemorySize
        public struct RuntimeMemoryUsage
        {
            public int Cpu;
            public int Gpu;
        }

        /// <summary>
        /// Gets the runtime memory usage of the specified texture settings.
        /// </summary>
        /// <param name="format">The texture format</param>
        /// <param name="width">The texture width in pixels</param>
        /// <param name="height">The texture height in pixels</param>
        /// <param name="hasmips">Whether the texture contains mipmaps</param>
        /// <param name="isreadable">Whether the texture data is readable</param>
        /// <param name="iscubemap">Whether the texture is a CubeMap</param>
        /// <returns>The runtime memory usage in bytes.</returns>
        public static RuntimeMemoryUsage GetRuntimeMemorySize(TextureFormat format, int width, int height, bool hasmips, bool isreadable, bool iscubemap)
        {
            // This is basically the TextureFormat enum members of the latest Unity version, or the values that are new since 4.3.
            // Having them duplicated here is not nice, I know, but it's way simpler to support
            // multiple Unity versions this way rather than providing separate DLL's for each Unity build.
            const TextureFormat TextureFormat_DXT5Crunched = (TextureFormat)29;
            const TextureFormat TextureFormat_DXT1Crunched = (TextureFormat)28;
            const TextureFormat TextureFormat_ETC2_RGB4 = (TextureFormat)0x2d;
            const TextureFormat TextureFormat_ETC2_RGB4_PUNCHTHROUGH_ALPHA = (TextureFormat)0x2e;
            const TextureFormat TextureFormat_ETC2_RGBA8 = (TextureFormat)0x2f;
            const TextureFormat TextureFormat_ASTC_RGB_4x4 = (TextureFormat)48;
            const TextureFormat TextureFormat_ASTC_RGBA_4x4 = (TextureFormat)54;
            const TextureFormat TextureFormat_ASTC_RGB_5x5 = (TextureFormat)49;
            const TextureFormat TextureFormat_ASTC_RGBA_5x5 = (TextureFormat)55;
            const TextureFormat TextureFormat_ASTC_RGB_6x6 = (TextureFormat)50;
            const TextureFormat TextureFormat_ASTC_RGBA_6x6 = (TextureFormat)56;
            const TextureFormat TextureFormat_ASTC_RGB_8x8 = (TextureFormat)51;
            const TextureFormat TextureFormat_ASTC_RGBA_8x8 = (TextureFormat)57;
            const TextureFormat TextureFormat_ASTC_RGB_10x10 = (TextureFormat)52;
            const TextureFormat TextureFormat_ASTC_RGBA_10x10 = (TextureFormat)58;
            const TextureFormat TextureFormat_ASTC_RGB_12x12 = (TextureFormat)53;
            const TextureFormat TextureFormat_ASTC_RGBA_12x12 = (TextureFormat)59;


            var bitsPerPixel = -1.0f;
            switch(format)
            {
                case TextureFormat.PVRTC_RGBA2:
                case TextureFormat.PVRTC_RGB2:
                    bitsPerPixel = 2;
                    break;

                case TextureFormat.PVRTC_RGB4:
                case TextureFormat.PVRTC_RGBA4:
                case TextureFormat.ETC_RGB4:
                case TextureFormat.ATC_RGB4:
                case TextureFormat.DXT1:
                case TextureFormat_DXT1Crunched:
                    bitsPerPixel = 4;
                    break;

                case TextureFormat.Alpha8:
                case TextureFormat.DXT5:
                case TextureFormat.ATC_RGBA8:
                case TextureFormat_DXT5Crunched:
                    bitsPerPixel = 8;
                    break;

                case TextureFormat.ARGB4444:
                case TextureFormat.RGBA4444:
                case TextureFormat.RGB565:
                    bitsPerPixel = 16;
                    break;

                case TextureFormat.RGB24:
                    bitsPerPixel = 24;
                    break;

                case TextureFormat.RGBA32:
                case TextureFormat.ARGB32:
                case TextureFormat.BGRA32:
                    bitsPerPixel = 32;
                    break;

                // Unity has not exposed the ETC2 texture formats to TextureFormat yet, only to TextureImporterFormat
                case TextureFormat_ETC2_RGB4:
                case TextureFormat_ETC2_RGB4_PUNCHTHROUGH_ALPHA:
                    bitsPerPixel = 4;
                    break;

                case TextureFormat_ETC2_RGBA8:
                    bitsPerPixel = 8;
                    break;

                case TextureFormat_ASTC_RGB_4x4:
                case TextureFormat_ASTC_RGBA_4x4:
                    GetMemorySizeASTC(ref width, ref height, ref bitsPerPixel, 4, 4);
                    break;

                case TextureFormat_ASTC_RGB_5x5:
                case TextureFormat_ASTC_RGBA_5x5:
                    GetMemorySizeASTC(ref width, ref height, ref bitsPerPixel, 5, 5);
                    break;

                case TextureFormat_ASTC_RGB_6x6:
                case TextureFormat_ASTC_RGBA_6x6:
                    GetMemorySizeASTC(ref width, ref height, ref bitsPerPixel, 6, 6);
                    break;

                case TextureFormat_ASTC_RGB_8x8:
                case TextureFormat_ASTC_RGBA_8x8:
                    GetMemorySizeASTC(ref width, ref height, ref bitsPerPixel, 8, 8);
                    break;

                case TextureFormat_ASTC_RGB_10x10:
                case TextureFormat_ASTC_RGBA_10x10:
                    GetMemorySizeASTC(ref width, ref height, ref bitsPerPixel, 10, 10);
                    break;

                case TextureFormat_ASTC_RGB_12x12:
                case TextureFormat_ASTC_RGBA_12x12:
                    GetMemorySizeASTC(ref width, ref height, ref bitsPerPixel, 12, 12);
                    break;

                // couldn't find any info on bits per pixels for these formats
                // http://www.adobe.com/devnet/flashruntimes/articles/introducing-compressed-textures.html
                //case TextureFormat.ATF_RGB_DXT1: // also removed in Unity 5
                //case TextureFormat.ATF_RGBA_JPG: // also removed in Unity 5
                //case TextureFormat.ATF_RGB_JPG: // also removed in Unity 5
                default:
                    return new RuntimeMemoryUsage() { Gpu = -Mathf.Abs((int)format), Cpu = -Mathf.Abs((int)format) };
            }

            var sizeInBytes = (width * height * bitsPerPixel) / 8.0f;
            
            if (hasmips)
                sizeInBytes *= 1.3333333333333f; // mimaps add an additional overhead of 33%

            if (iscubemap)
                sizeInBytes *= 6; // cubemap has 6 faces

            var result = new RuntimeMemoryUsage();
            result.Gpu = Mathf.RoundToInt(sizeInBytes);

            // if a texture is readable, a copy of the texture data will be made,
            // doubling the amount of memory required for texture asset. 
            // see http://docs.unity3d.com/Manual/class-TextureImporter.html for details
            if (isreadable && !iscubemap) // for some reason, cubemaps are never considered readable
            {
                // this is only valid for uncompressed and DTX compressed textures,
                // other types of compressed textures cannot be read from.
                switch (format)
                {
                    case TextureFormat.ARGB4444:
                    case TextureFormat.RGB565:
                    case TextureFormat.RGBA4444:
                    case TextureFormat.Alpha8:
                    case TextureFormat.DXT1:
                    case TextureFormat.DXT5:
                    case TextureFormat.RGB24:
                    case TextureFormat.RGBA32:
                    case TextureFormat.ARGB32:
                    case TextureFormat.BGRA32:
                    case TextureFormat_DXT1Crunched:
                    case TextureFormat_DXT5Crunched:
                        result.Cpu = Mathf.RoundToInt(sizeInBytes);
                        break;
                }
            }

            return result;
        }

        static void GetMemorySizeASTC(ref int textureWidth, ref int textureHeight, ref float bitsPerPixel, int blockWidth, int blockHeight)
        {
            // https://www.opengl.org/registry/specs/KHR/texture_compression_astc_hdr.txt
            // Given a 2D image which is W x H pixels in size, with block size
            // w x h, the size of the image in blocks is:
            //    Bw = ceiling(W/w)
            //    Bh = ceiling(H/h)

            textureWidth = Mathf.CeilToInt(textureWidth / (float)blockWidth) * blockWidth;
            textureHeight = Mathf.CeilToInt(textureHeight / (float)blockHeight) * blockHeight;
            bitsPerPixel = 1.0f / (blockWidth * blockHeight) * 128;
        }
        #endregion

        #region GetMipmapCount
        /// <summary>
        /// Gets the number of mipmaps in the specified texture.
        /// </summary>
        /// <param name="texture">The texture.</param>
        /// <returns>The number of mipmaps. 0 indicates an error occured, 1 indicates it's not using mipmaps.</returns>
        public static int GetMipmapCount(Texture texture)
        {
            if (null == _countMipmaps)
                return 0;

            var args = new object[] { texture };
            return (int)_countMipmaps.Invoke(null, args);
        }
        #endregion

        #region HasAlpha
        /// <summary>
        /// Gets whether the specified texture has an alpha-channel.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>true when it contains an alpha-channel, false otherwise.</returns>
        public static bool HasAlpha(Texture texture)
        {
            if (TextureUtil2.IsNormalMap(texture))
                return false;

            return HasAlphaTextureFormat(GetTextureFormat(texture));
        }
        #endregion

        #region HasAlphaTextureFormat
        /// <summary>
        /// Gets whether the specified TextureFormat has an alpha-channel.
        /// </summary>
        /// <param name="format">The TextureFormat</param>
        /// <returns>true when it has an alpha-channel, false otherwise.</returns>
        public static bool HasAlphaTextureFormat(TextureFormat format)
        {
            if (null == _hasAlphaTextureFormat)
                return false;

            var args = new object[] { format };
            return (bool)_hasAlphaTextureFormat.Invoke(null, args);
        }
        #endregion

        #region GetTextureFormat
        /// <summary>
        /// Gets the TextureFormat of the specified texture.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>The TextureFormat on success, 0 otherwise.</returns>
        public static TextureFormat GetTextureFormat(Texture texture)
        {
            if (null == _getTextureFormat)
                return (TextureFormat)0;

            var args = new object[] { texture };
            return (TextureFormat)_getTextureFormat.Invoke(null, args);
        }
        #endregion

        #region GetTextureFormatString
        /// <summary>
        /// Gets the string-representation of the specified TextureFormat.
        /// </summary>
        /// <param name="format">The TextureFormat</param>
        /// <param name="type">The TextureType</param>
        /// <returns></returns>
        public static string GetTextureFormatString(TextureFormat format, TextureType type)
        {
            if (type == TextureType.Normalmap)
            {
                switch (format)
                {
                    case TextureFormat.ARGB4444: return "Nm 16 bit";
                    case TextureFormat.ARGB32: return "Nm 32 bit";
                    case TextureFormat.DXT5: return "DXTnm";
                }
            }

            if (null == _getTextureFormatString)
                return "???";

            var args = new object[] { format };
            return _getTextureFormatString.Invoke(null, args) as string;
        }
        #endregion

        #region GetTextureFormatShortString
        /// <summary>
        /// Gets the string-representation of the specified TextureFormat in short form.
        /// </summary>
        /// <param name="format">The TextureFormat</param>
        /// <returns>the string</returns>
        public static string GetTextureFormatShortString(TextureFormat format)
        {
            switch (format)
            {
                // these are not exposed to TextureFormat yet
                case (TextureFormat)0x2d: return "ETC2_RGB4";
                case (TextureFormat)0x2e: return "ETC2_RGB4_PUNCHTHROUGH_ALPHA";
                case (TextureFormat)0x2f: return "ETC2_RGBA8";
                default:
                    break;
            }

            return format.ToString();
        }
        #endregion

        #region GetTextureType
        public enum TextureType
        {
            None,
            Normalmap,
            Lightmap,
            Image,
            Cookie,
            Cursor,
            GUI,
            Reflection,
            Cubemap,
            Sprite
        }

        public static class TextureTypeStrings
        {
            public const string Normalmap = "Normalmap";
            public const string Lightmap = "Lightmap";
            public const string Image = "Texture";
            public const string Cookie = "Cookie";
            public const string Cursor = "Cursor";
            public const string GUI = "GUI";
            public const string Reflection = "Reflection";
            public const string Cubemap = "Cubemap";
            public const string Sprite = "Sprite";
        }

        public static Color GetTextureTypeChartColor(TextureType type)
        {
            switch (type)
            {
                case TextureType.Normalmap: return new Color32(114,147,203,255);
                case TextureType.Lightmap: return new Color32(128, 133, 133, 255);
                case TextureType.Image: return new Color32(211, 94, 96, 255);
                case TextureType.Cookie: return new Color32(204, 194, 16, 255);
                case TextureType.Cursor: return Color.white;
                case TextureType.GUI: return new Color32(144, 103, 167, 255);
                case TextureType.Reflection: return new Color32(171, 104, 87, 255);
                case TextureType.Cubemap: return new Color32(225, 151, 76, 255);
                case TextureType.Sprite: return new Color32(132, 186, 91, 255);
            }
            return Color.white;
        }

        /// <summary>
        /// Gets the TextureType of the specified texture.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <param name="importer">The TextureImporter</param>
        /// <returns>The TextureType</returns>
        /// <remarks>
        /// This is basically a helper function to get the TextureType, because to get the
        /// type from 'importer.textureType' has so many special cases.
        /// </remarks>
        public static TextureType GetTextureType(Texture texture, TextureImporter importer)
        {
            if (null != importer)
            {
                switch (importer.textureType)
                {
                    case TextureImporterType.Advanced:
                        {
                            if (importer.spriteImportMode != SpriteImportMode.None)
                                return TextureType.Sprite;
                            if (importer.normalmap)
                                return TextureType.Normalmap;
                            if (importer.lightmap)
                                return TextureType.Lightmap;
                            if (importer.generateCubemap != TextureImporterGenerateCubemap.None)
                                return TextureType.Cubemap;
                            return TextureType.Image;
                        }

                    case TextureImporterType.Bump: return TextureType.Normalmap;
                    case TextureImporterType.Cookie: return TextureType.Cookie;
                    case TextureImporterType.Cursor: return TextureType.Cursor;
                    case TextureImporterType.GUI: return TextureType.GUI;
                    case TextureImporterType.Image: return TextureType.Image;
                    case TextureImporterType.Lightmap: return TextureType.Lightmap;
#if UNITY_5
                    case TextureImporterType.Cubemap: return TextureType.Reflection; // actually a cubemap
#else
                    case TextureImporterType.Reflection: return TextureType.Reflection; // actually a cubemap
#endif
                    case TextureImporterType.Sprite: return TextureType.Sprite;
                }
            }

            var cubemap = texture as Cubemap;
            if (null != cubemap)
                return TextureType.Cubemap;

            return TextureType.None;
        }

        /// <summary>
        /// Gets a string-representation of the specified TextureType.
        /// </summary>
        /// <param name="type">The TextureType</param>
        /// <returns>The string of the TextureType</returns>
        public static string GetTextureTypeString(TextureType type)
        {
            switch (type)
            {
                case TextureType.Cookie: return TextureTypeStrings.Cookie;
                case TextureType.Cubemap: return TextureTypeStrings.Cubemap;
                case TextureType.Cursor: return TextureTypeStrings.Cursor;
                case TextureType.GUI: return TextureTypeStrings.GUI;
                case TextureType.Image: return TextureTypeStrings.Image;
                case TextureType.Lightmap: return TextureTypeStrings.Lightmap;
                case TextureType.Normalmap: return TextureTypeStrings.Normalmap;
                case TextureType.Reflection: return TextureTypeStrings.Reflection;
                case TextureType.Sprite: return TextureTypeStrings.Sprite;
            }

            return "???";
        }
        #endregion

        #region GetUsageMode
#if UNITY_5
        // This is actually a copy of UnityEditor.TextureUsageMode.
        // This has been made internal in Unity 5.0
        enum TextureUsageMode
        {
            Default,
            LightmapDoubleLDR,
            LightmapRGBM,
            NormalmapDXT5nm,
            NormalmapPlain,
            RGBMEncoded,
            AlwaysPadded
        }
#endif
        /// <summary>
        /// Gets the TextureUsageMode of the specified texture.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>The TextureUsageMode</returns>
        static TextureUsageMode GetUsageMode(Texture texture)
        {
            if (null == _getUsageMode)
                return TextureUsageMode.Default;

            var args = new object[] { texture };
            return (TextureUsageMode)_getUsageMode.Invoke(null, args);
        }
        #endregion

        #region IsCompressedTextureFormat
        /// <summary>
        /// Gets whether the specified format is using compression.
        /// </summary>
        /// <param name="format">The TextureFormat</param>
        /// <returns>true when it is using compression, false otherwise</returns>
        public static bool IsCompressedTextureFormat(TextureFormat format)
        {
            if (null == _isCompressedTextureFormat)
                return false;

            var args = new object[] { format };
            return (bool)_isCompressedTextureFormat.Invoke(null, args);
        }
        #endregion

        #region IsPowerOfTwo
        /// <summary>
        /// Gets whether the specified texture size is power of two.
        /// </summary>
        public static bool IsPowerOfTwo(Texture texture)
        {
            if (null == _isNonPowerOfTwo)
                return false;

            if (texture is Cubemap)
                return true;

            if (!(texture is Texture2D))
                return false;

            var args = new object[] { texture };
            return !(bool)_isNonPowerOfTwo.Invoke(null, args);
        }
        #endregion

        #region IsNormalMap
        /// <summary>
        /// Gets whether the specified texture is a normalmap.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>true when it's a normalmap, false otherwise.</returns>
        public static bool IsNormalMap(Texture texture)
        {
            switch (GetUsageMode(texture))
            {
                case TextureUsageMode.NormalmapPlain:
                case TextureUsageMode.NormalmapDXT5nm:
                    return true;
            }
            return false;
        }
        #endregion

        #region IsLightMap
        /// <summary>
        /// Gets whether the specified texture is a lightmap.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <returns>true when it's a lightmap, false otherwise.</returns>
        public static bool IsLightMap(Texture texture)
        {
            switch (GetUsageMode(texture))
            {
                case TextureUsageMode.LightmapRGBM:
                case TextureUsageMode.LightmapDoubleLDR:
                    return true;
            }
            return false;
        }
        #endregion

        #region IsReadable
        /// <summary>
        /// Gets whether the specified texture data is readable.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <param name="importer">The TextureImporter or null. If you specify an importer, the method can execute faster.</param>
        /// <returns></returns>
        public static bool IsReadable(Texture texture, TextureImporter importer)
        {
            var cubemap = texture as Cubemap;
            if (null != cubemap)
            {
                if (null == _isCubemapReadable)
                    return false;

                var args = new object[] { cubemap };
                return (bool)_isCubemapReadable.Invoke(null, args);
            }

            // if there is no importer passed, we need to get it first, which can be a really slow operation
            if (null == importer)
            {
                var path = AssetDatabase.GetAssetPath(texture);
                importer = string.IsNullOrEmpty(path) ? null : AssetImporter.GetAtPath(path) as TextureImporter;
            }

            if (null != importer)
                return importer.isReadable;

            return false;
        }
        #endregion

        #region GetOriginalWidthAndHeight
        /// <summary>
        /// Gets the width and height of the source texture asset.
        /// </summary>
        /// <param name="texture">The Texture</param>
        /// <param name="importer">The TextureImporter</param>
        /// <param name="width">The output width</param>
        /// <param name="height">The output height</param>
        public static void GetOriginalWidthAndHeight(Texture texture, TextureImporter importer, out int width, out int height)
        {
            width = 0;
            height = 0;

            var cubemap = texture as Cubemap;
            if (null != cubemap)
            {
                width = GetGLWidth(texture);
                height = GetGLHeight(texture);
                return;
            }

            if (null != importer)
            {
                TextureImporter2.GetWidthAndHeight(importer, ref width, ref height);
                return;
            }
        }

        static int GetGLWidth(Texture texture)
        {
            if (null == _getGLWidth)
                return -1;

            var args = new object[] { texture };
            return (int)_getGLWidth.Invoke(null, args);
        }

        static int GetGLHeight(Texture texture)
        {
            if (null == _getGLHeight)
                return -1;

            var args = new object[] { texture };
            return (int)_getGLHeight.Invoke(null, args);
        }
        #endregion

        #region ToSourceCode
        /// <summary>
        /// Gets the C# source code of the specified texture.
        /// </summary>
        /// <param name="texture">Texture to get the source code for.</param>
        /// <returns>A string containing the source code of the texture</returns>
        /// <remarks>
        /// If you don't want editor only textures to appear in the Unity Texture Selector,
        /// you must not store them in the Assets folder. Thus my workaround is to include textures
        /// in the source code instead.
        /// </remarks>
        public static string ToSourceCode(Texture2D texture)
        {
            var builder = new System.Text.StringBuilder(4096);
            var pixels = texture.GetPixels32();

            //builder.AppendLine("readonly static Color32[] PixelData = new Color32[] {");
            builder.AppendLine("new Color32[] {");

            var n = 0;
            while (n < pixels.Length)
            {
                var x=0;
                while (x < 6 && n < pixels.Length)
                {
                    var pixel = pixels[n];
                    builder.Append(string.Format(" new Color32({0},{1},{2},{3}),", pixel.r, pixel.g, pixel.b, pixel.a));
                    n++;
                    x++;
                }
                builder.AppendLine();
            }
            builder.AppendLine("};");

            return builder.ToString();
        }
        #endregion
    }
}
