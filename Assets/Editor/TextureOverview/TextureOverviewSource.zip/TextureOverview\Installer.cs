﻿using System;
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace TextureOverview
{
    public class MainWindow : EditorFramework.InstallerWindow
    {
        #region CreateWindow
        /// <summary>
        /// Called from TextureOverviewMenuItem.cs to create the window.
        /// This method checks if the plugin runs in the minimum required Unity version
        /// and displays a message in case it is not.
        /// </summary>
        public static EditorWindow CreateWindow()
        {
            var wnd = EditorWindow.GetWindow(typeof(MainWindow));
            wnd.title = Globals.ProductTitle;
            wnd.minSize = new Vector2(220, 90);
            return wnd;
        }
        #endregion

        void OnEnable()
        {
            base.ProductTitle = Globals.ProductTitle;
            base.AssetStoreUrl = Globals.ProductAssetStoreUrl;
            base.FeedbackUrl = Globals.ProductFeedbackUrl;
            base.MinimumMajorVersion = Globals.MinimumMajorVersion;
            base.MinimumMinorVersion = Globals.MinimumMinorVersion;
        }
    }
}
