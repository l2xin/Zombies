﻿using System.Collections.Generic;
using EditorFramework;
using UnityEditor;
using UnityEngine;

namespace TextureOverview
{
    public class TextureMemoryUsageData
    {
        /// <summary>
        /// Indicates to what texture type the data belongs.
        /// </summary>
        public TextureUtil2.TextureType TextureType;

        /// <summary>
        /// The number of bytes textures of type 'TextureType' consume.
        /// </summary>
        public long Size;

        /// <summary>
        /// How many % the Size represents.
        /// </summary>
        public float Percentage;
    }

    public class TextureMemoryUsageInfo
    {
        /// <summary>
        /// The number of bytes all textures found in 'UsagePerType' consume combined.
        /// </summary>
        public long TotalSize;

        /// <summary>
        /// Provides memory usage data for each texture type (eg Sprite, Normalmap, Lightmap, etc)
        /// </summary>
        public List<TextureMemoryUsageData> UsagePerType = new List<TextureMemoryUsageData>();
    }

    /// <summary>
    /// Represents the overlay window that is displayed on-top of the main window.
    /// </summary>
    public class TextureMemoryUsageOverlay
    {
        #region Private Fields
        [System.Flags]
        enum Panels
        {
            RuntimeMemory = 1 << 0,
            GraphicsMemory = 1 << 1,
            MainMemory = 1 << 2,
            StorageMemory = 1 << 3,
        }

        Rect _position = new Rect(20, 20, 665, 254);
        int _visible = -1; // -1 = uninitialized, 0=not visible, 1=visible
        Panels _VisiblePanels = Panels.RuntimeMemory | Panels.StorageMemory;
        EditorWindow _Owner;
        #endregion

        #region Public Fields
        public TextureMemoryUsageInfo CpuUsage;
        public TextureMemoryUsageInfo GpuUsage;
        public TextureMemoryUsageInfo RuntimeUsage;
        public TextureMemoryUsageInfo StorageUsage;
        #endregion

        #region Visible
        /// <summary>
        /// Gets whether the overlay is visible.
        /// </summary>
        public bool Visible
        {
            get
            {
                if (_visible < 0) // not initialized yet?
                {
                    _visible = EditorPrefs.GetInt(string.Format("{0}.MemoryUsage.Visible", Globals.ProductId), 0);
                    _position.x = EditorPrefs.GetFloat(string.Format("{0}.MemoryUsage.Position.X", Globals.ProductId), _position.x);
                    _position.y = EditorPrefs.GetFloat(string.Format("{0}.MemoryUsage.Position.Y", Globals.ProductId), _position.y);
                    _VisiblePanels = (Panels)EditorPrefs.GetInt(string.Format("{0}.MemoryUsage.VisiblePanels", Globals.ProductId), (int)(Panels.RuntimeMemory | Panels.StorageMemory));
                }

                return _visible>0;
            }
            set
            {
                if (_visible != (value?1:0))
                {
                    _visible = value?1:0;
                    EditorPrefs.SetInt(string.Format("{0}.MemoryUsage.Visible", Globals.ProductId), _visible);
                    EditorPrefs.SetInt(string.Format("{0}.MemoryUsage.VisiblePanels", Globals.ProductId), (int)_VisiblePanels);
                }
            }
        }

        /// <summary>
        /// Gets the number of visible panels.
        /// </summary>
        int VisiblePanelCount
        {
            get
            {
                var count = 0;
                if ((_VisiblePanels & Panels.RuntimeMemory) != 0) count++;
                if ((_VisiblePanels & Panels.StorageMemory) != 0) count++;
                if ((_VisiblePanels & Panels.GraphicsMemory) != 0) count++;
                if ((_VisiblePanels & Panels.MainMemory) != 0) count++;
                return count;
            }
        }
        #endregion

        #region OnGUI
        /// <summary>
        /// Draw and handle overlay GUI.
        /// </summary>
        /// <param name="owner">The editor window that owns the overlay.</param>
        public void OnGUI(EditorWindow owner)
        {
            _Owner = owner;
            if (!Visible || _Owner == null || RuntimeUsage == null || StorageUsage == null || CpuUsage == null || GpuUsage == null)
                return;

            var oldpos = _position;
            _position = ClampPosition(owner, GUI.Window(0, _position, DrawOverlayWindow, ""));

            // if position changed, store new values in prefs to we can restore them when the plugin gets closed and reopened
            if (oldpos != _position)
            {
                EditorPrefs.SetFloat(string.Format("{0}.MemoryUsage.Position.X", Globals.ProductId), _position.x);
                EditorPrefs.SetFloat(string.Format("{0}.MemoryUsage.Position.Y", Globals.ProductId), _position.y);
            }
        }
        #endregion

        #region OverlayWindowFunction
        /// <summary>
        /// Draws the overlay window content
        /// </summary>
        void DrawOverlayWindow(int id)
        {
            // Adjust overlay width depending on the visible panels count
            _position.width = Mathf.Max(1,VisiblePanelCount) * 335;

            // draw overlay background
            EditorGUI.DrawPreviewTexture(new Rect(0, 16, _position.width, _position.height), EditorStyles.toolbar.normal.background);

            // draw close button into overlay titlebar
            if (GUI.Button(new Rect(_position.width - 16, 0, 16, 16), new GUIContent("X", "Close Overlay"), EditorStyles.label))
            {
                Visible = false;
                return;
            }

            EditorGUILayout.BeginVertical();

            // Draw info panels
            EditorGUILayout.BeginHorizontal();
            if ((_VisiblePanels & Panels.RuntimeMemory) != 0)
            {
                DrawUsageInfo(RuntimeUsage, "Runtime (Graphics + Main) Memory Usage");
                EditorGUILayout2.Separator(GUILayout.Width(1), GUILayout.ExpandHeight(true));
            }
            if ((_VisiblePanels & Panels.GraphicsMemory) != 0)
            {
                DrawUsageInfo(GpuUsage, "Graphics Memory Usage");
                EditorGUILayout2.Separator(GUILayout.Width(1), GUILayout.ExpandHeight(true));
            }
            if ((_VisiblePanels & Panels.MainMemory) != 0)
            {
                DrawUsageInfo(CpuUsage, "Main Memory Usage");
                EditorGUILayout2.Separator(GUILayout.Width(1), GUILayout.ExpandHeight(true));
            }
            if ((_VisiblePanels & Panels.StorageMemory) != 0)
            {
                DrawUsageInfo(StorageUsage, "Storage Memory Usage");
                EditorGUILayout2.Separator(GUILayout.Width(1), GUILayout.ExpandHeight(true));
            }
            EditorGUILayout.EndHorizontal();

            // Draw panel selector
            if (VisiblePanelCount == 0)
                GUILayout.FlexibleSpace(); // when no info is drawn, make sure the selector is still at the bottom

            EditorGUILayout.BeginHorizontal();
            var newInfos = (Panels)EditorGUILayout.EnumMaskField(_VisiblePanels);
            if (newInfos != _VisiblePanels)
                _VisiblePanels = newInfos;
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.EndVertical();

            GUI.DragWindow();
        }
        #endregion

        #region DrawUsageInfo
        /// <summary>
        /// Draws GUI for the specified usageInfo
        /// </summary>
        void DrawUsageInfo(TextureMemoryUsageInfo usageInfo, string title)
        {
            float ColumnWidthType = 80;
            float ColumnWidthSize = 65;
            float ColumnWidthBar = 120;
            float ColumnWidthPercentage = 50;

            EditorGUILayout.BeginVertical();

            GUILayout.Label(title, EditorStyles.boldLabel);
            GUILayout.Space(2);

            if (usageInfo.UsagePerType.Count > 0)
            {
                var ratio = 1 / usageInfo.UsagePerType[0].Percentage;

                foreach (var data in usageInfo.UsagePerType)
                {
                    EditorGUILayout.BeginHorizontal();
                    GUILayout.Label(TextureUtil2.GetTextureTypeString(data.TextureType), GUILayout.Width(ColumnWidthType));
                    GUILayout.Label(EditorUtility2.FormatBytes(data.Size), GUIStyles.LabelRight, GUILayout.Width(ColumnWidthSize));

                    var charcolor = GUIColors.TintIfPlaying(TextureUtil2.GetTextureTypeChartColor(data.TextureType));
                    EditorGUI.DrawRect(GUILayoutUtility.GetRect(1, 19, GUILayout.Width(Mathf.Max(1, data.Percentage * ColumnWidthBar * ratio))), charcolor);

                    GUILayout.Label(string.Format("{0:F1}%", data.Percentage * 100), GUILayout.Width(ColumnWidthPercentage));
                    EditorGUILayout.EndHorizontal();
                    GUILayout.Space(1);
                }
            }

            GUILayout.Label(string.Format("= {0}", EditorUtility2.FormatBytes(usageInfo.TotalSize)), GUIStyles.BoldLabelRight, GUILayout.Width(8 + ColumnWidthType + ColumnWidthSize));

            EditorGUILayout.EndVertical();
        }
        #endregion

        #region ClampPosition
        /// <summary>
        /// Clamps the overlay window into the owner window rect. This is to make
        /// sure the user cannot completely move the overlay outside the window and
        /// therefore never be able to see the overlay anymore.
        /// </summary>
        Rect ClampPosition(EditorWindow owner, Rect overlayPosition)
        {
            float margin = 32;

            if (overlayPosition.xMax <= margin)
                overlayPosition.x = margin - overlayPosition.width;

            if (overlayPosition.x >= owner.position.width - margin)
                overlayPosition.x = owner.position.width - margin;

            if (overlayPosition.yMax <= margin)
                overlayPosition.y = margin - overlayPosition.height;

            if (overlayPosition.y >= owner.position.height - margin)
                overlayPosition.y = owner.position.height - margin;

            return overlayPosition;
        }
        #endregion
    }
}
